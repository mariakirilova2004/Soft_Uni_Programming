﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-2E3N18H;Database=MusicHub;Trusted_Connection=True";
    }
}
