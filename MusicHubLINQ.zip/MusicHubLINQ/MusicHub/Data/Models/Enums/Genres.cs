﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Data.Models.Enums
{
    public enum Genres
    {
        Blues, 
        Rap, 
        PopMusic, 
        Rock, 
        Jaz
    }
}
