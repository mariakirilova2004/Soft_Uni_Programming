﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            //string command = Console.ReadLine();
            //string result = GetBooksByAgeRestriction(db, command);
            //string result = GetGoldenBooks(db);
            //string result = GetBooksByPrice(db);
            //string result = GetBooksNotReleasedIn(db, 2000);
            string result = GetAuthorNamesEndingIn(db, "dy");
            Console.WriteLine(result);
        }

        //Return in a single string all book titles, each on a new line, that have an age restriction,
        //equal to the given command.Order the titles alphabetically
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            StringBuilder str = new StringBuilder();

            AgeRestriction ageRestriction = Enum.Parse<AgeRestriction>(command, true);
            var books = context.Books
                .ToArray()
                .Where(x => x.AgeRestriction == ageRestriction)
                .OrderBy(x => x.Title)
                .Select(x => x.Title)
                .ToArray();

            foreach (var title in books)
            {
                str.AppendLine(title);
            }


            return str.ToString();
        }

        //Return in a single string title of the golden edition books that have 
        //less than 5000 copies, each on a new line.Order them by book id ascending.
        public static string GetGoldenBooks(BookShopContext context)
        {
            StringBuilder str = new StringBuilder();

           var books = context.Books
                .ToArray()
                .Where(x => x.EditionType == EditionType.Gold)
                .Where(x => x.Copies < 5000)
                .OrderBy(x => x.BookId)
                .Select(x => x.Title)
                .ToArray();

            foreach (var title in books)
            {
                str.AppendLine(title);
            }


            return str.ToString();
        }

        //Return in a single string all titles and prices of books with a price higher than 40,
        //each on a new row in the format given below.Order them by price descending.
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder str = new StringBuilder();

            var books = context.Books
                 .ToArray()
                 .Where(x => x.Price > 40)
                 .OrderByDescending(x => x.Price)
                 .Select(x =>  $"{x.Title} - ${x.Price:0.00}" )
                 .ToArray();

            foreach (var title in books)
            {
                str.AppendLine(title);
            }


            return str.ToString();
        }

        //Return in a single string all titles of books that are NOT released in a given year.
        //Order them by book id ascending
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            StringBuilder str = new StringBuilder();

            var books = context.Books
                 .ToArray()
                 .Where(x => x.ReleaseDate.Value.Year != year)
                 .OrderBy(x => x.BookId)
                 .Select(x => $"{x.Title}")
                 .ToArray();

            foreach (var title in books)
            {
                str.AppendLine(title);
            }


            return str.ToString();
        }

        //Return in a single string the titles of books by a given list of categories. The list of categories will be given in a single line separated by one or more spaces.
        //Ignore casing. Order by title alphabetically
        //public static string GetBooksByCategory(BookShopContext context, string input)
        //{
        //    StringBuilder str = new StringBuilder();
        //    string[] categories = input.Split().ToArray();
        //
        //    var books = context.Books
        //         .Where(x => x.BookCategories.Contains(categories))
        //         .OrderBy(x => x.BookId)
        //         .Select(x => $"{x.Title}")
        //         .ToArray();
        //
        //    foreach (var title in books)
        //    {
        //        str.AppendLine(title);
        //    }
        //
        //
        //    return str.ToString();
        //}

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            StringBuilder str = new StringBuilder();

            var books = context.Authors
                 .ToArray()
                 .Where(x => x.FirstName.Substring(x.FirstName.Length - input.Length) == input)
                 .OrderBy(x => x.FirstName)
                 .Select(x => $"{x.FirstName} {x.LastName}")
                 .ToArray();

            foreach (var title in books)
            {
                str.AppendLine(title);
            }


            return str.ToString();
        }
    }

    
}
