﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastFoodServices.DTO.Category
{
    public class CreateCategoryDto
    {
        public string CategoryName { get; set; }
    }
}
