﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastFoodServices.DTO.Category
{
    public class ListAllCategoriesDto
    {
        public string CategoryName { get; set; }
    }
}
