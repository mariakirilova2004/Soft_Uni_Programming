﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastFoodServices.DTO.Position
{
    public class EmployeeRegisterPositionAvailable
    {
        public int PositionId { get; set; }

        public string PositionName { get; set; }

    }
}
