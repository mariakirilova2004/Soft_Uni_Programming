﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FastFoodServices.DTO.Employee
{
    public class ListAllEmployeesDto
    {
        public string Name { get; set; }

        public int Age { get; set; }

        public string Address { get; set; }

        public string Position { get; set; }
    }
}
