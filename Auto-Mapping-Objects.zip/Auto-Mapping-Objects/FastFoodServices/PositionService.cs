﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using FastFood.Data;
using FastFoodServices.DTO.Position;
using FastFoodServices.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FastFoodServices
{
    public class PositionService : IPositionService
    {
        private readonly FastFoodContext fastFoodContext;
        private readonly IMapper mapper;

        public PositionService(FastFoodContext foodContext, IMapper mapper)
        {
            this.fastFoodContext = foodContext;
            this.mapper = mapper;
        }

        public ICollection<EmployeeRegisterPositionAvailable> GetPositionsAvailable()
        {
            return fastFoodContext.Positions.ProjectTo<EmployeeRegisterPositionAvailable>(this.mapper.ConfigurationProvider).ToList();
        }
    }
}
