﻿namespace FastFood.Core.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using Data;
    using FastFoodServices.DTO.Employee;
    using FastFoodServices.DTO.Position;
    using FastFoodServices.Interfaces;
    using Microsoft.AspNetCore.Mvc;
    using ViewModels.Employees;

    public class EmployeesController : Controller
    {
        private readonly IPositionService positionService;
        private readonly IMapper mapper;
        private readonly IEmployeeService employeeService;

        public EmployeesController(IMapper mapper, IPositionService positionService, IEmployeeService employeeService)
        {
            this.positionService = positionService;
            this.mapper = mapper;
        }

        public IActionResult Register()
        {
            ICollection<EmployeeRegisterPositionAvailable> positionsDto =
                this.positionService.GetPositionsAvailable();

            List<RegisterEmployeeViewModel> registerViewModels = this.mapper.Map<ICollection<EmployeeRegisterPositionAvailable>, ICollection<RegisterEmployeeViewModel>>(positionsDto).ToList();

            return this.View(registerViewModels);
        }

        [HttpPost]
        public IActionResult Register(RegisterEmployeeInputModel model)
        {
            if (!ModelState.IsValid)
            {
                return this.RedirectToAction("Register");
            }

            RegisterEmployeeDto employeeDto = this.mapper.Map<RegisterEmployeeDto>(model);

            this.employeeService.Register(employeeDto);

            return this.RedirectToAction("All");
        }

        public IActionResult All()
        {
            ICollection<ListAllEmployeesDto> employeesDtos =
                this.employeeService.All();
            List<EmployeesAllViewModel> employeesAllViewModels =
                this.mapper
                .Map<ICollection<ListAllEmployeesDto>, ICollection<EmployeesAllViewModel>>(employeesDtos).ToList();
            return this.View(employeesAllViewModels);
        }
    }
}
