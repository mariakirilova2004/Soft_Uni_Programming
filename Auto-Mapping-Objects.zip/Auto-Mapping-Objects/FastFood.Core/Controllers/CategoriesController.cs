﻿namespace FastFood.Core.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using AutoMapper;
    using AutoMapper.QueryableExtensions;
    using Data;
    using FastFood.Models;
    //using FastFoodServices.DTO.Category;
    using FastFoodServices.Interfaces;
    using Microsoft.AspNetCore.Mvc;
    using ViewModels.Categories;

    public class CategoriesController : Controller
    {
        //private readonly ICategoryService categoryService;
        //private readonly IMapper mapper;

        //public CategoriesController(IMapper mapper, ICategoryService categoryService)
        //{
        //    this.categoryService = categoryService;
        //    this.mapper = mapper;
        //}

        public IActionResult Create()
        {
            return this.View();
        }

        [HttpPost]
        public IActionResult Create(CreateCategoryInputModel model)
        {
            if (!ModelState.IsValid)
            {
                return this.RedirectToAction("Create");
            }

            //CreateCategoryDto createCategoryDto = this.mapper.Map<CreateCategoryDto>(model);

            //this.categoryService.Create(createCategoryDto);

            return this.RedirectToAction("All");
        }

        //public IActionResult All()
        //{
        //    ICollection<ListAllCategoriesDto> categoriesDtos = this.categoryService.All();

        //    List<CategoryAllViewModel> categoryViewModels = this.mapper.Map<ICollection<ListAllCategoriesDto>, ICollection<CategoryAllViewModel>>(categoriesDtos).ToList();

        //    return this.View("All", categoryViewModels);
        //}
    }
}
