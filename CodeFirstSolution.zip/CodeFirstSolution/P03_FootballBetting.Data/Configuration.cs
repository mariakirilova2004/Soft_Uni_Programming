﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-2E3N18H;Database=Bet365;Trusted_Connection=True;";

    }
}
