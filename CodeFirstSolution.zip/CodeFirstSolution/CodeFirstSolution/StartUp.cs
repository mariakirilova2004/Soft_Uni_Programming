﻿using P03_FootballBetting.Data;
using System;

namespace P03_FootballBetting
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            FootballBettingContext dbContext = new FootballBettingContext();
            dbContext.Database.EnsureCreated();
            Console.WriteLine("Db Created successfully!");
            dbContext.Database.EnsureDeleted();
        }
    }
}
