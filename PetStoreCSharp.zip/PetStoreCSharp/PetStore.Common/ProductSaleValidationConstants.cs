﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetStore.Common
{
    public static class ProductSaleValidationConstants
    {
        public const int BILL_INFO_MAX_LENGTH = 500;  
    }
}
