﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetStore.Common
{
    public static class BreedValidationConstants
    {
        public const int NAME_MAX_LENGTH = 50;
    }
}
