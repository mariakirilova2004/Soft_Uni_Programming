﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetStore.Common
{
    public static class DataBaseConfig
    {
        public const string CONNECTIONSTRING = @"Server=.;Database=PetStoreWebApp;IntegratedSecurity=True;";
    }
}
