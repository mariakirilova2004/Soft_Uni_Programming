﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetStore.Common
{
    public static class PetValidationConstants
    {
        public const int PET_NAME_MAX_LENGTH = 50;
        public const int PET_DESCRIPTION_MAX_LENGTH = 50;
    }
}
