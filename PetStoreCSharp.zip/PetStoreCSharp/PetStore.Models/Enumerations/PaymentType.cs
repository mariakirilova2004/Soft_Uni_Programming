﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetStore.Models
{
    public enum PaymentType
    {
        Cash = 1,
        Card = 2
    }
}
