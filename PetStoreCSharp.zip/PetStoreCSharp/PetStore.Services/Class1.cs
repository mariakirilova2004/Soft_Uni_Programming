﻿namespace PetStore.Services
{
    public class Class1
    {

    }
}